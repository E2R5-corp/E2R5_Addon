# E2R5

## An extension for browser based on chromium

*	The button links to the youtube page of the E2R5
*	The logo of the E2R5tv appears on the intra

*Improvements and features will come*
